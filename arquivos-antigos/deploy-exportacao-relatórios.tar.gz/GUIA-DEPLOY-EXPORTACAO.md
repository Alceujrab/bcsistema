# Guia de Deploy - Sistema de Exportação de Relatórios

## Arquivos Criados/Modificados

### 1. Novos Arquivos Criados:
```
app/Services/ReportExportService.php
app/Services/PdfService.php
resources/views/reports/pdf/layout.blade.php
resources/views/reports/pdf/transactions.blade.php
resources/views/reports/pdf/reconciliations.blade.php
resources/views/reports/pdf/cash-flow.blade.php
resources/views/reports/pdf/categories.blade.php
public/css/reports-export.css
```

### 2. Arquivos Modificados:
```
composer.json (adicionadas dependências PDF/Excel)
routes/web.php (novas rotas de exportação)
app/Http/Controllers/ReportController.php (métodos de exportação)
resources/views/reports/transactions.blade.php (função exportReport)
resources/views/reports/reconciliations.blade.php (função exportData)
resources/views/reports/cash-flow.blade.php (função exportData)
resources/views/reports/categories.blade.php (funções exportData e exportCategory)
```

## Comandos para Execução no Servidor

### 1. Fazer backup dos arquivos atuais:
```bash
# No diretório do projeto
cp -r app app_backup_$(date +%Y%m%d_%H%M%S)
cp -r resources resources_backup_$(date +%Y%m%d_%H%M%S)
cp -r routes routes_backup_$(date +%Y%m%d_%H%M%S)
cp composer.json composer.json.backup
cp -r public public_backup_$(date +%Y%m%d_%H%M%S)
```

### 2. Upload dos arquivos (via FTP/SCP):
```bash
# Estrutura de diretórios a serem enviados:
project_root/
├── app/Services/ReportExportService.php
├── app/Services/PdfService.php
├── app/Http/Controllers/ReportController.php (substituir)
├── resources/views/reports/pdf/
│   ├── layout.blade.php
│   ├── transactions.blade.php
│   ├── reconciliations.blade.php
│   ├── cash-flow.blade.php
│   └── categories.blade.php
├── resources/views/reports/
│   ├── transactions.blade.php (substituir)
│   ├── reconciliations.blade.php (substituir)
│   ├── cash-flow.blade.php (substituir)
│   └── categories.blade.php (substituir)
├── public/css/reports-export.css
├── routes/web.php (substituir)
└── composer.json (substituir)
```

### 3. Comandos no servidor (via SSH):
```bash
# 1. Navegar para o diretório do projeto
cd /caminho/para/seu/projeto

# 2. Instalar/atualizar dependências do Composer
composer install --no-dev --optimize-autoloader

# 3. Limpar e recriar cache
php artisan config:clear
php artisan route:clear
php artisan cache:clear
php artisan view:clear

# 4. Recriar cache otimizado para produção
php artisan config:cache
php artisan route:cache
php artisan view:cache

# 5. Otimizar autoloader
composer dump-autoload --optimize

# 6. Verificar permissões
chmod -R 755 storage/
chmod -R 755 bootstrap/cache/
chown -R www-data:www-data storage/ bootstrap/cache/
```

### 4. Teste das Funcionalidades:

#### Teste 1 - Verificar Rotas:
```bash
php artisan route:list | grep "reports/export"
```

#### Teste 2 - Testar URLs no navegador:
```
https://seudominio.com/reports/export/transactions/csv
https://seudominio.com/reports/export/transactions/pdf
https://seudominio.com/reports/export/reconciliations/csv
https://seudominio.com/reports/export/cash-flow/csv
https://seudominio.com/reports/export/categories/csv
```

#### Teste 3 - Verificar logs de erro:
```bash
tail -f storage/logs/laravel.log
```

## Estrutura de Teste Completa

### 1. Script de Verificação:
```bash
#!/bin/bash
echo "=== Verificação do Sistema de Exportação ==="

echo "1. Verificando arquivos..."
test -f app/Services/ReportExportService.php && echo "✓ ReportExportService.php" || echo "✗ ReportExportService.php FALTANDO"
test -f app/Services/PdfService.php && echo "✓ PdfService.php" || echo "✗ PdfService.php FALTANDO"
test -d resources/views/reports/pdf && echo "✓ Diretório PDF templates" || echo "✗ Diretório PDF templates FALTANDO"

echo "2. Verificando rotas..."
php artisan route:list | grep "reports/export" > /dev/null && echo "✓ Rotas de exportação registradas" || echo "✗ Rotas de exportação NÃO encontradas"

echo "3. Verificando cache..."
test -f bootstrap/cache/routes.php && echo "✓ Cache de rotas existe" || echo "✗ Cache de rotas não existe"

echo "4. Verificando permissões..."
test -w storage/logs && echo "✓ Diretório de logs gravável" || echo "✗ Diretório de logs NÃO gravável"

echo "=== Verificação Concluída ==="
```

### 2. URLs de Teste com Parâmetros:
```
# Transações com filtros
/reports/export/transactions/csv?date_from=2024-01-01&date_to=2024-12-31&type=credit

# Conciliações com filtros
/reports/export/reconciliations/pdf?status=approved&bank_account_id=1

# Fluxo de caixa
/reports/export/cash-flow/csv?start_date=2024-01-01&end_date=2024-01-31

# Categorias
/reports/export/categories/pdf?date_from=2024-01-01&date_to=2024-12-31
```

## Solução de Problemas Comuns

### 1. Erro 500 - Internal Server Error:
```bash
# Verificar logs
tail -f storage/logs/laravel.log

# Verificar permissões
chmod -R 755 storage/
chown -R www-data:www-data storage/
```

### 2. Classe não encontrada:
```bash
# Limpar e recriar autoloader
composer dump-autoload
php artisan clear-compiled
```

### 3. Rota não encontrada:
```bash
# Limpar cache de rotas
php artisan route:clear
php artisan route:cache
```

### 4. Erro de memória em relatórios grandes:
```bash
# Aumentar limite de memória no php.ini
memory_limit = 512M

# Ou no arquivo .htaccess
php_value memory_limit 512M
```

## Checklist Final de Deploy

- [ ] Backup realizado
- [ ] Arquivos enviados para o servidor
- [ ] Composer install executado
- [ ] Cache limpo e recriado
- [ ] Permissões verificadas
- [ ] Rotas testadas no navegador
- [ ] Logs verificados sem erros
- [ ] Testes de exportação funcionando
- [ ] Interface com botões funcionando

## Comandos de Rollback (se necessário)

```bash
# Restaurar arquivos do backup
mv app_backup_YYYYMMDD_HHMMSS app
mv resources_backup_YYYYMMDD_HHMMSS resources
mv routes_backup_YYYYMMDD_HHMMSS routes
mv composer.json.backup composer.json
mv public_backup_YYYYMMDD_HHMMSS public

# Reinstalar dependências
composer install
php artisan config:clear
php artisan route:clear
php artisan cache:clear
```

### ⚠️ IMPORTANTE - Correção de Caminhos Aplicada:
Todos os caminhos de exportação foram corrigidos para incluir o prefixo `/bc/`:
- ✅ Correto: `https://usadosar.com.br/bc/reports/export/transactions/pdf`
- ❌ Incorreto: `https://usadosar.com.br/reports/export/transactions/pdf`

As seguintes views foram corrigidas:
- `resources/views/reports/transactions.blade.php` 
- `resources/views/reports/reconciliations.blade.php`
- `resources/views/reports/cash-flow.blade.php`
- `resources/views/reports/categories.blade.php`
- `resources/views/reports/index.blade.php`

Este guia garante um deploy seguro e testável da funcionalidade de exportação de relatórios.
