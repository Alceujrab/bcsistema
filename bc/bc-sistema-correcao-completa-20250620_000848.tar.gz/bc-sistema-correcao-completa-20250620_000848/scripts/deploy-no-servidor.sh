#!/bin/bash

echo "========================================================"
echo "  APLICANDO CORREÇÃO COMPLETA NO SERVIDOR"
echo "========================================================"
echo ""

# Verificar se estamos no Laravel
if [ ! -f "artisan" ]; then
    echo "❌ ERRO: Execute este script no diretório raiz do Laravel"
    exit 1
fi

echo "🔄 Fazendo backup dos arquivos atuais..."
BACKUP_DIR="backup-pre-correcao-$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

# Backup
cp app/Http/Controllers/ImportController.php "$BACKUP_DIR/" 2>/dev/null
cp app/Http/Controllers/ReconciliationController.php "$BACKUP_DIR/" 2>/dev/null
cp app/Services/StatementImportService.php "$BACKUP_DIR/" 2>/dev/null
cp app/Models/StatementImport.php "$BACKUP_DIR/" 2>/dev/null

echo "✅ Backup criado em: $BACKUP_DIR"

echo ""
echo "📂 Copiando arquivos corrigidos..."

# Criar diretórios se não existirem
mkdir -p app/Http/Controllers/
mkdir -p app/Services/
mkdir -p app/Models/
mkdir -p resources/views/

# Copiar arquivos
cp arquivos/ImportController.php app/Http/Controllers/
cp arquivos/ReconciliationController.php app/Http/Controllers/
cp arquivos/StatementImportService.php app/Services/
cp arquivos/StatementImport.php app/Models/

# Copiar views
cp -r arquivos/resources/views/imports/ resources/views/
cp -r arquivos/resources/views/reconciliations/ resources/views/

echo "✅ Arquivos copiados com sucesso!"

echo ""
echo "🧹 Limpando cache..."
php artisan config:clear
php artisan view:clear
php artisan route:clear
php artisan cache:clear

echo ""
echo "🔧 Definindo permissões..."
chmod -R 755 storage/
chmod -R 755 bootstrap/cache/
chown -R www-data:www-data storage/ bootstrap/cache/ 2>/dev/null || echo "   (Execute como root para aplicar chown)"

echo ""
echo "🧪 Testando sistema..."
php artisan tinker --execute="
try {
    echo 'Teste de modelos:' . PHP_EOL;
    echo '- StatementImport: ' . \App\Models\StatementImport::count() . ' registros' . PHP_EOL;
    echo '- BankAccount: ' . \App\Models\BankAccount::count() . ' registros' . PHP_EOL;
    echo '✅ Sistema funcionando!' . PHP_EOL;
} catch(Exception \$e) {
    echo '❌ ERRO: ' . \$e->getMessage() . PHP_EOL;
    exit(1);
}
"

echo ""
echo "========================================================"
echo "✅ CORREÇÃO APLICADA COM SUCESSO!"
echo "========================================================"
echo ""
echo "O sistema foi corrigido e está funcionando!"
echo ""
echo "Para testar:"
echo "1. Acesse: seu-dominio.com/imports"
echo "2. Teste a funcionalidade de importação"
echo ""
echo "Em caso de problemas:"
echo "1. Restaure o backup: cp $BACKUP_DIR/* app/..."
echo "2. Limpe o cache: php artisan cache:clear"
echo ""
